﻿using Microsoft.AspNetCore.Mvc;
using runpath.test.webapi.queries;
using System.Threading.Tasks;

namespace runpath.test.webapi.controllers
{
    [Route("api/albums")]
    [ApiController]
    public class AlbumsController : Controller
    {
        private readonly IAlbumsQuery _albumQuery;

        public AlbumsController(IAlbumsQuery albumQuery)
        {
            _albumQuery = albumQuery;
        }

        [HttpGet("{userId}")]
        public async Task<IActionResult> Index([FromRoute] int userId)
        {
            return new OkObjectResult(
                await _albumQuery.GetAlbumsByUserId(userId));
        }
    }
}