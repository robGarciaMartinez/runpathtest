﻿namespace runpath.test.webapi
{
    public class DataEndpointSettings
    {
        public string AlbumsUrl { get; set; }

        public string PhotosUrl { get; set; }
    }
}
