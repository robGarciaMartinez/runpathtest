﻿using runpath.test.webapi.dto;
using System.Threading.Tasks;

namespace runpath.test.webapi.queries
{
    public interface IAlbumsQuery
    {
        Task<AlbumQueryResultDto[]> GetAlbumsByUserId(int userId);
    }
}
