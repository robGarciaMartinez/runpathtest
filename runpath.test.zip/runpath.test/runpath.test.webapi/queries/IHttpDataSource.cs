﻿using runpath.test.webapi.dto;
using System.Threading.Tasks;

namespace runpath.test.webapi.queries
{
    public interface IHttpDataSource<TData> where TData : BaseDto
    {
        Task<TData[]> GetData(string url);
    }
}
