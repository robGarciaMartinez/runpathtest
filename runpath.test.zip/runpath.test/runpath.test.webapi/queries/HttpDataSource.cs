﻿using Newtonsoft.Json;
using runpath.test.webapi.dto;
using System;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;

namespace runpath.test.webapi.queries
{
    public class HttpDataSource<TData> : IHttpDataSource<TData> where TData : BaseDto
    {
        private readonly HttpClient _httpClient;

        public HttpDataSource(HttpClient httpClient)
        {
            _httpClient = httpClient;
        }

        public async Task<TData[]> GetData(string url)
        {
            if (string.IsNullOrWhiteSpace(url))
            {
                throw new ArgumentException("Url is null or empty");
            }

            var responseString = await _httpClient.GetStringAsync(url);
            if (string.IsNullOrWhiteSpace(responseString))
            {
                return Enumerable.Empty<TData>().ToArray(); 
            }

            return JsonConvert.DeserializeObject<TData[]>(responseString);
        }
    }
}
