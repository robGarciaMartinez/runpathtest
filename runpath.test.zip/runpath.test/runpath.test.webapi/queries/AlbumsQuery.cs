﻿using Microsoft.Extensions.Options;
using runpath.test.webapi.dto;
using System;
using System.Linq;
using System.Threading.Tasks;

namespace runpath.test.webapi.queries
{
    public class AlbumsQuery : IAlbumsQuery
    {
        private readonly IHttpDataSource<AlbumDto> _albumsHttpDataSource;
        private readonly IHttpDataSource<PhotoDto> _photosHttpDataSource;
        private readonly DataEndpointSettings _dataEndpointSettings;

        public AlbumsQuery(
            IHttpDataSource<AlbumDto> albumsHttpDataSource, 
            IHttpDataSource<PhotoDto> photosHttpDataSource,
            IOptions<DataEndpointSettings> options)
        {
            _albumsHttpDataSource = albumsHttpDataSource;
            _photosHttpDataSource = photosHttpDataSource;
            _dataEndpointSettings = options.Value ?? throw new ArgumentNullException(nameof(DataEndpointSettings));
        }

        public async Task<AlbumQueryResultDto[]> GetAlbumsByUserId(int userId)
        {
            var albumsTask = _albumsHttpDataSource.GetData(_dataEndpointSettings.AlbumsUrl);
            var photosTask = _photosHttpDataSource.GetData(_dataEndpointSettings.PhotosUrl);

            await Task.WhenAll(albumsTask, photosTask);

            var allAlbums = albumsTask.Result;
            var allPhotos = photosTask.Result;

            return allAlbums
                .Where(al => al.UserId == userId)
                .Select(al => new AlbumQueryResultDto
                {
                    Album = al,
                    Photos = allPhotos.Where(ph => ph.AlbumId == al.Id).ToArray()
                }).ToArray();
        }
    }
}
