﻿namespace runpath.test.webapi.dto
{
    public class PhotoDto : BaseDto
    {
        public int AlbumId { get; set; }

        public string Url { get; set; }

        public string ThumbnailUrl { get; set; }
    }
}
