﻿namespace runpath.test.webapi.dto
{
    public class AlbumDto : BaseDto
    {
        public int UserId { get; set; }
    }
}
