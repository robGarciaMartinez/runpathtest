﻿namespace runpath.test.webapi.dto
{
    public class AlbumQueryResultDto
    {
        public AlbumDto Album { get; set; }

        public PhotoDto[] Photos { get; set; }
    }
}
