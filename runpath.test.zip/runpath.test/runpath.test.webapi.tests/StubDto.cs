﻿using runpath.test.webapi.dto;

namespace runpath.test.webapi.tests
{
    public class StubDto : BaseDto
    {
    }
}
