﻿using Microsoft.Extensions.Options;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using runpath.test.webapi.dto;
using runpath.test.webapi.queries;
using System.Linq;
using System.Threading.Tasks;

namespace runpath.test.webapi.tests
{
    [TestClass]
    public class AlbumsQueryTests
    {
        private IOptions<DataEndpointSettings> options;
        private Mock<IHttpDataSource<AlbumDto>> _albumsHttpDataSourceMock;
        private Mock<IHttpDataSource<PhotoDto>> _photosHttpDataSourceMock;

        [TestInitialize]
        public void Initialise()
        {
            var settings = new DataEndpointSettings
            {
                AlbumsUrl = "http://albums.co.uk",
                PhotosUrl = "http://photos.co.uk"
            };

            options = Options.Create(settings);
            _albumsHttpDataSourceMock = new Mock<IHttpDataSource<AlbumDto>>();
            _photosHttpDataSourceMock = new Mock<IHttpDataSource<PhotoDto>>();
        }

        [TestMethod]
        public async Task CanGetAllAlbumsOfUser()
        {
            var userId = 1;
            var albums = new AlbumDto[]
            {
                new AlbumDto { Id = 1, Title = "Album title 1", UserId = 1 },
                new AlbumDto { Id = 2, Title = "Album title 2", UserId = 1 },
                new AlbumDto { Id = 3, Title = "Album title 3", UserId = 2 },
            };

            var photos = new PhotoDto[]
            {
                new PhotoDto { Id = 1, Title = "Album title 1", AlbumId = 1 },
                new PhotoDto { Id = 2, Title = "Album title 2", AlbumId = 1 },
                new PhotoDto { Id = 3, Title = "Album title 3", AlbumId = 1 },
                new PhotoDto { Id = 4, Title = "Album title 4", AlbumId = 2 },
                new PhotoDto { Id = 5, Title = "Album title 5", AlbumId = 2 }
            };

            _albumsHttpDataSourceMock
                .Setup(ah => ah.GetData(It.IsAny<string>()))
                .Returns(Task.FromResult(albums));

            _photosHttpDataSourceMock
                .Setup(ah => ah.GetData(It.IsAny<string>()))
                .Returns(Task.FromResult(photos));

            var albumsQuery = new AlbumsQuery(
                _albumsHttpDataSourceMock.Object,
                _photosHttpDataSourceMock.Object,
                options);

            var results = await albumsQuery.GetAlbumsByUserId(userId);
            Assert.AreEqual(albums.Where(al => al.UserId == userId).Count(), results.Length);

            for (int index = 0; index < results.Length; index++)
            {
                Assert.AreEqual(
                    photos.Where(ph => ph.AlbumId == results[index].Album.Id).Count(),
                    results[index].Photos.Length);
            }
        }
    }
}
