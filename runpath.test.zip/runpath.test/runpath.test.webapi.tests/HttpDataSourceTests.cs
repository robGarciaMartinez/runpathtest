using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using Moq.Protected;
using Newtonsoft.Json;
using runpath.test.webapi.queries;
using System;
using System.Net;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;

namespace runpath.test.webapi.tests
{
    [TestClass]
    public class HttpDataSourceTests
    { 
        [TestMethod]
        [ExpectedException(typeof(ArgumentException))]
        public async Task GetDataFromHttpSourceWhenUrlNull()
        {
            var mockMessageHandler = CreateHttpMessageHandler(HttpStatusCode.OK);
            var httpDataSource = new HttpDataSource<StubDto>(new HttpClient(mockMessageHandler.Object));
            var results = await httpDataSource.GetData(default(string));
        }

        [TestMethod]
        public async Task GetDataFromHttpSourceWhenNoContent()
        {
            var mockMessageHandler = CreateHttpMessageHandler(HttpStatusCode.OK);
            var httpDataSource = new HttpDataSource<StubDto>(new HttpClient(mockMessageHandler.Object));

            var results = await httpDataSource.GetData("http://randomurl.co.uk");

            Assert.IsTrue(results.Length == 0);
        }

        [TestMethod]
        public async Task GetDataFromHttpSource()
        {
            var endpointResults = new StubDto[]
            {
                new StubDto() { Id = 1, Title = "Stub Object 1" },
                new StubDto() { Id = 2, Title = "Stub Object 2" }
            };

            var mockMessageHandler = CreateHttpMessageHandler(HttpStatusCode.OK, endpointResults);
            var httpDataSource = new HttpDataSource<StubDto>(new HttpClient(mockMessageHandler.Object));

            var results = await httpDataSource.GetData("http://randomurl.co.uk");

            Assert.AreEqual(endpointResults.Length, results.Length);
            for(int index = 0; index < endpointResults.Length; index++)
            {
                Assert.AreEqual(endpointResults[index].Id, results[index].Id);
                Assert.AreEqual(endpointResults[index].Title, results[index].Title);
            }
        }

        private Mock<HttpMessageHandler> CreateHttpMessageHandler(HttpStatusCode statusCode, object content = null)
        {
            var responseMessage = new HttpResponseMessage
            {
                StatusCode = statusCode
            };

            if (content != null)
            {
                responseMessage.Content = new StringContent(JsonConvert.SerializeObject(content));
            }

            var mockMessageHandler = new Mock<HttpMessageHandler>();
            mockMessageHandler.Protected()
                .Setup<Task<HttpResponseMessage>>("SendAsync", ItExpr.IsAny<HttpRequestMessage>(), ItExpr.IsAny<CancellationToken>())
                .ReturnsAsync(responseMessage);

            return mockMessageHandler;
        }
    }
}
